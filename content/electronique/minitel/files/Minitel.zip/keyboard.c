/* Out
 * <A:C>
 * In
 * <RB0:RB7>
 */
#include <xc.h>
#include <pic16f1518.h>

#include "keyboard.h"
#include "config.h"
#include "main.h"

void getKeys(byte* keys) {
    signed char i;
    for (i = 0; i < 8; i++) {
        KEYA = (i & 1) ? 1 : 0;
        KEYB = (i & 2) ? 1 : 0;
        KEYC = (i & 4) ? 1 : 0;
        _delay_ms(1);
        *(keys + i) = PORTB^0xFF;
    }

}