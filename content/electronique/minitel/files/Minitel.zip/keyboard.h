#ifndef KEYBOARD_H
#define	KEYBOARD_H

/* 0 2 1 3 4 6 5 7 8 9 A B C D E F
 * I O O O O I I I I I I O O O O I
 * 7 3 2 1 0 6 5 4 3 2 1 7 6 5 4 0
 */
/*ESSENTIAL DEFINITIONS*/
//                     IO
#define KEY_BAS      0x70
#define KEY_CORR     0x71
#define KEY_ANNUL    0x72
#define KEY_HAUT     0x73
#define KEY_ENTREE   0x74
#define KEY_GAUCHE   0x76
#define KEY_DROITE   0x75
#define KEY_MAJ      0x77
#define KEY_Y        0x60
#define KEY_E        0x62
#define KEY_R        0x61
#define KEY_T        0x63
#define KEY_INT      0x64
#define KEY_TIR      0x66
#define KEY_2PTS     0x65
#define KEY_PTVI     0x67
#define KEY_H        0x50
#define KEY_D        0x52
#define KEY_F        0x51
#define KEY_G        0x53
#define KEY_1        0x54
#define KEY_7        0x56
#define KEY_4        0x55
#define KEY_AST      0x57
#define KEY_APO      0x40
#define KEY_ESC      0x42
#define KEY_VIR      0x41
#define KEY_PT       0x43
#define KEY_REPET    0x44
#define KEY_RETOUR   0x46
#define KEY_ENVOI    0x45
#define KEY_SUITE    0x47
#define KEY_N        0x30
#define KEY_C        0x32
#define KEY_V        0x31
#define KEY_B        0x33
#define KEY_2        0x34
#define KEY_8        0x36
#define KEY_5        0x35
#define KEY_0        0x37
#define KEY_SOMM     0x20
#define KEY_Z        0x22
#define KEY_A        0x21
#define KEY_GUIDE    0x23
#define KEY_P        0x24
#define KEY_I        0x26
#define KEY_O        0x25
#define KEY_U        0x27
#define KEY_CTRL     0x10
#define KEY_S        0x12
#define KEY_Q        0x11
#define KEY_FCT      0x13
#define KEY_M        0x14
#define KEY_L        0x16
#define KEY_K        0x15
#define KEY_J        0x17
#define KEY_ESP      0x00
#define KEY_X        0x02
#define KEY_W        0x01
#define KEY_FIN      0x03
#define KEY_3        0x04
#define KEY_9        0x06
#define KEY_6        0x05
#define KEY_DIE      0x07

/*Useful Macro*/
#define _isSet(keys, choice) ( keys[choice&0x0F] & (1 << (choice>>4)) ) ? 1:0

/*Prototype*/
void getKeys(char* keys);

#endif	/* KEYBOARD_H */

