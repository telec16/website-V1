#ifndef EF9345_H
#define	EF9345_H

#include "config.h"

/*ESSENTIAL DEFINITIONS*/
#define GR_R0      0x20
#define GR_R1      0x21
#define GR_R2      0x22
#define GR_R3      0x23
#define GR_R4      0x24
#define GR_R5      0x25
#define GR_R6      0x26
#define GR_R7      0x27
#define GR_EXEC    0x08
#define GR_REXEC   0xF7

#define GR_TGS     0x81
#define GR_MAT     0x82
#define GR_PAT     0x83
#define GR_DOR     0x84
#define GR_ROR     0x87
#define GR_NOP     0x91
#define GR_KRF     0x00
#define GR_CLF     0x05
#define GR_VRM     0x95

/*Prototype*/
void writeByte(byte addr, byte data);
void writeByteNS(byte addr, byte data);
byte readByte(byte addr);
void waitBusy();
void EF9345_cleanup();
void init_EF9345();
void EF9345_print(byte chr, byte col, byte lig);

#endif	/* EF9345_H */

