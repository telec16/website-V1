#include <xc.h>
#include <pic16f1518.h>

#include "serial.h"


void serial_write(unsigned char out_char) {
    while (!TRMT); // while NOT buffer empty
    TXREG = out_char;
}

unsigned char serial_read() {
    byte out = -1;
    if (OERR) {
        CREN = 0;
        out = RCREG;
        asm("nop");
        out = RCREG;
        asm("nop");
        out = RCREG;
        CREN = 1;
    }
    if (RCIF)
        out = RCREG;
    if (FERR)
        out = -2;

    return out;
}

void serial_print(char* out_string) {
    while (*out_string != '\0') {
        serial_write(*out_string);
        out_string++;
    }
}

//Debug Only
void serial_write_binary(byte out_char) {
    signed char i;
    for (i = 7; i >= 0; i--)
        serial_write(((out_char >> i)&1) ? '1' : '0');
    serial_write('b');
    serial_write('\n');
}

byte serial_read_binary() {
    signed char i;
    byte out = 0;

    for (i = 7; i >= 0; i--) {
        while (!RCIF);
        out += serial_read() == '1' ? 1 << i : 0;
    }

    return out;
}
