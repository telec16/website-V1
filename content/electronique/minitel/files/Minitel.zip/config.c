#include <xc.h>
#include <pic16f1518.h>

#include "config.h"

void init() {
    OSCCON = 0b01111000; //osc to 16MHz
    RCSTA = 0b10010000; //Enable USART
    TXSTA = 0b00100000;
    SPBRGL = 51; //FOSCI/(64*4800)-1;
    BAUDCON = 0x00;
    PIE1 = 0x00; //Disable interupt (enable Rx: 0b00100000)
    OPTION_REG = 0x00; //Enable Pull-Up

    ANSELA = 0x00; //We don't want analog input !
    ANSELB = 0x00;
    ANSELC = 0x00;

    TRISA = 0x00; //Parallel communication with graphical chip (EF9345)
    TRISB = 0xFF; //Keyboard input
    TRISC = 0b10000000; //AS|DS|RW | S|A|B | Tx|Rx

    PORTA = 0x00;
    WPUB = 0xFF; //Pull-up on Keyboard input
    PORTC = 0x00;

    return;
}
