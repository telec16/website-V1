#ifndef SERIAL_H
#define	SERIAL_H

#include "config.h"

/*Prototype*/
void serial_write(unsigned char out_char);
char serial_read();
void serial_print(char* out_string);
void serial_write_binary(byte out_char);
byte serial_read_binary();

#endif	/* SERIAL_H */

