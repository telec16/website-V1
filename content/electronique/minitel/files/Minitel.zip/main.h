#ifndef MAIN_H
#define	MAIN_H

/*Useful Macro*/
#define _delay_us(x)	_delay(((x*FCY)/1000000L))	// delays x us
#define _delay_ms(x)	_delay(((x*FCY)/1000L))         // delays x ms
#define _delay_s(x)	_delay(((x*FCY)/1L))            // delays x s

#endif	/* MAIN_H */

