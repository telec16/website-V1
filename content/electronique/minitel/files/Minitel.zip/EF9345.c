#include <xc.h>
#include <pic16f1518.h>

#include "EF9345.h"
#include "main.h"

void writeByte(byte addr, byte data) {
    if (addr & GR_EXEC)
        waitBusy();
    do {
        /*serial_write(readByte(GR_R0));//*/
        //Check sync
        while (!(readByte(GR_R0) & 0x04));
        /*serial_write(readByte(GR_R0));
        serial_write('\n');//*/

        //Preset
        TRISA = 0x00;
        GRRW = 1;
        GRDS = 1;
        //Write Addr
        GRAS = 1;
        LATA = addr;
        _delay_us(1);
        GRAS = 0;
        //Write Data
        _delay_us(1);
        GRRW = 0;
        LATA = data;
        _delay_us(1);
        //Reset
        GRRW = 1;
        GRAS = 1;

        //Test without the XQR bit
        if (addr & GR_EXEC)
            return;
    } while (readByte(addr) != data);

    return;
}

//Not secure

void writeByteNS(byte addr, byte data) {
    //Preset
    TRISA = 0x00;
    GRRW = 1;
    GRDS = 1;
    //Write Addr
    GRAS = 1;
    LATA = addr;
    _delay_us(1);
    GRAS = 0;
    //Write Data
    _delay_us(1);
    GRRW = 0;
    LATA = data;
    _delay_us(1);
    //Reset
    GRRW = 1;
    GRAS = 1;

    return;
}

byte readByte(byte addr) {
    byte data;
    //Preset
    TRISA = 0x00;
    GRRW = 1;
    GRDS = 1;
    //Write Addr
    GRAS = 1;
    LATA = addr;
    _delay_us(1);
    GRAS = 0;
    //Read Data
    TRISA = 0xFF;
    _delay_us(1);
    GRDS = 0;
    _delay_us(1);
    data = PORTA;
    //Reset
    GRDS = 1;
    GRAS = 1;

    return data;
}

void waitBusy() {
    /*
    byte data = readByte(GR_R0);
    serial_write(data);
    while (data & 0x80)
        data = readByte(GR_R0);
    serial_write(data);
     //*/
    while (readByte(GR_R0) & 0x80);

    return;
}

void init_EF9345() {
    /*http://forum.system-cfg.com/viewtopic.php?f=25&t=5731&start=15#p91193*/
    /*Datasheet P 15*/

    //Nop
    writeByteNS(GR_R0 + GR_EXEC, GR_NOP);
    //VRM
    writeByteNS(GR_R0 + GR_EXEC, GR_VRM);

    //ROR
    writeByte(GR_R1, 0x08); //0000'1000
    writeByte(GR_R0 + GR_EXEC, GR_ROR);

    //DOR
    writeByte(GR_R1, 0x13); //0001'0011
    writeByte(GR_R0 + GR_EXEC, GR_DOR);

    //TGS
    writeByte(GR_R1, 0x10); //0000'0001
    writeByte(GR_R0 + GR_EXEC, GR_TGS);

    //PAT
    writeByte(GR_R1, 0x67); //0110'0111
    writeByte(GR_R0 + GR_EXEC, GR_PAT);

    //MAT
    writeByte(GR_R1, 0x00); //0010'1001
    writeByte(GR_R0 + GR_EXEC, GR_MAT);

    EF9345_cleanup();

    return;
}
void EF9345_cleanup()
{
    writeByte(GR_R1, 0x20); //C
    writeByte(GR_R2, 0x00); //B
    writeByte(GR_R3, 0x70); //A
    writeByte(GR_R6, 0x08);
    writeByte(GR_R7, 0x00);

    writeByte(GR_R0 + GR_EXEC, GR_CLF);
    _delay_ms(5);
    writeByteNS(GR_R0 + GR_EXEC, GR_NOP);
}

void EF9345_print(byte chr, byte col, byte lig) {
    //selectionne le caract�re et le jeu
    writeByte(GR_R1, chr);
    //attribut du caract�re
    writeByte(GR_R3, 0x70);
    writeByte(GR_R2, 0x00);
    //ligne
    writeByte(GR_R6, lig);
    //colone
    writeByte(GR_R7, col);
    //commande  KRF

    writeByte(GR_R0 + GR_EXEC, GR_KRF);
}