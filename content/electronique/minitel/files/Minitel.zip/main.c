/*INCLUSIONS*/
#include <xc.h>
#include <pic16f1518.h>
#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "main.h"
#include "keyboard.h"
#include "EF9345.h"
#include "serial.h"

int main(int argc, char** argv) {

    init();
    _delay_ms(500);

    byte i, j;
    byte msg[] = "Salut, je suis une ligne de service  _#X";
    unsigned char chr;
    byte keys[8];

    while (PORTB >= 0x3F); //On attend la mise sous tension du minitel
    serial_print("Ok\n");

    init_EF9345();
    //Ligne de service
    for (i = 0; i < 40; i++)
        EF9345_print(msg[i], i, 0);
    //Reste de l'�cran
    for (i = 0; i < 40; i++)
        for (j = 8; j < 32; j++)
            EF9345_print(j - 8 + (i % 2 ? 'A' : 'a'), i, j);

    while (1) {
        do
            i = serial_read(); while (i == 255);
        i -= '0';
        serial_write(i + '0');
        serial_write_binary(readByte(GR_R0));
        if (i > 3) {
            getKeys(&keys);
            if (_isSet(keys, KEY_REPET))
                writeByteNS(GR_R0 + GR_EXEC, GR_NOP);
            else if (_isSet(keys, KEY_FIN)) {
                EF9345_cleanup();
                serial_write_binary(readByte(GR_R0));
            }
        } else {
            chr = serial_read_binary();
            serial_write_binary(chr);

            writeByte(GR_R1, chr);
            writeByte(GR_R0 + GR_EXEC, 0x80 + i);
        }
        /*do
            chr = serial_read(); while (chr == 255);
        serial_write(chr);

        serial_print("\nKeyOut: \n");
        getKeys(&keys);
        for (i = 0; i < 8; i++)
            serial_write_binary(keys[i]);
        serial_write(_isSet(keys, KEY_ENVOI) ? '1' : '0');
        _delay_ms(500);*/
    }
    return (EXIT_FAILURE);
}
