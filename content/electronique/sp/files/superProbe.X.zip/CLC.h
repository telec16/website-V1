#ifndef CLC_H
#define	CLC_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "config.h"

void init_CLCs();
bool getCLCout(byte clc);

#endif	/* CLC_H */

