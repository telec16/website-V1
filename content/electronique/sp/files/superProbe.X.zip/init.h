#ifndef INIT_H
#define	INIT_H

#include <xc.h>

#include "ADC.h"
#include "CLC.h"
#include "CMP_DAC.h"
#include "TMR.h"

void start();

#endif	/* LOGIC_CELL_H */

